Contraction Timer tracks and stores all of your contraction data.


Project is set up for use in Eclipse, but should work in any Android development environment.

Virtual Device Setup:

Target: Android 2.2 - API Level 8
Skin: Default (WVGA800)

Target: Android 4.0.3 - API Level 15
Skin: Default (WXGA)