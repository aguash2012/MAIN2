package com.example.preggahoop;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Fetal_Heart_Rate extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fetal__heart__rate);
    }
}
