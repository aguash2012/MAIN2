package com.example.preggahoop;

import android.app.DatePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.Calendar;

public class Expected_Date_of_Delivery extends AppCompatActivity {

    private Toolbar toolbar;
    TextView mLmp;
    TextView mEdd;
    Button mDate;


    Calendar c;
    DatePickerDialog dpd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expected__date_of__delivery);
        toolbar = findViewById(R.id.toolBar);

        setSupportActionBar(toolbar);

        mLmp = (TextView)findViewById(R.id.LMP);
        mDate = (Button)findViewById(R.id.btnDate);


        mDate.setOnClickListener(new.OnClickListener() {
            @Override
            public void onClick(View v)
                c = Calendar.getInstance();
                int day = c.get(Calendar.DAY_OF_MONTH);
                int month = c.get(Calendar.MONTH);
                int year = c.get(Calendar.YEAR);

            dpd = new DatePickerDialog(Gestational_Period.this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int mYear, int mMonth, int mDay) {
                    mLmp.setText(mDay + "/" + (mMonth+1) + "/" + mYear);
                }
            }, day, month, year);

            }
        });


    }
}
