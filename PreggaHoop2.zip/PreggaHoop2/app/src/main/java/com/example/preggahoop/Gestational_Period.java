package com.example.preggahoop;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Gestational_Period extends AppCompatActivity {

    private static final String TAG = "Gestational_Period";

    private Toolbar toolbar;

    private TextView mLmp;
    private Button mDate;

    //TextView mLmp;
    //TextView mGp;
    //Button mDate;

    //DatePickerDialog dpd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestational__period);
        toolbar = findViewById(R.id.toolBar);

        setSupportActionBar(toolbar);

        mLmp = (TextView) findViewById(R.id.LMP);
        mDate = (Button) findViewById(R.id.btnDate);

        Intent incomingintent = getIntent();
        String date = incomingintent.getStringExtra("date");
        mLmp.setText(date);

        mDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Gestational_Period.this, CalendarActivity.class);
                startActivity(intent);
            }
        });


    }
}










        /*
        mLmp = (TextView) findViewById(R.id.LMP);
        mDate = (Button) findViewById(R.id.btnDate);

        mDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int day = c.get(Calendar.DAY_OF_MONTH);
                int month = c.get(Calendar.MONTH);
                int year = c.get(Calendar.YEAR);
                DatePickerDialog dateDialog = new DatePickerDialog(view.getContext(), datePickerListener, day, month, year);
                dateDialog.getDatePicker().setMaxDate(new Date().getTime());
                dateDialog.show();
            }
        });
    }

}




/*
        private DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int myear, int mmonth, int mday) {
                Calendar c = Calendar.getInstance();
                c.set(Calendar.YEAR, myear);
                c.set(Calendar.MONTH, mmonth);
                c.set(Calendar.DAY_OF_MONTH, mday);
                String format = new SimpleDateFormat("DD MMM YYYY").format(c.getTime());
                mLmp.setText(format);
                mGp.setText(c.set(Calendar.WEEK_OF_YEAR));
                //mGp.setText(Integer.toString(calculateGP(c.getTimeInMillis())));
            }
        };
    }
}
/*
        int calculateGP (long date){
            Calendar dolmp = Calendar.getInstance();
            dolmp.setTimeInMillis();
            Calendar today = Calendar.getInstance();
            int weeks = today.get(Calendar.WEEK_OF_YEAR) - dolmp.get(Calendar.WEEK_OF_YEAR);

            if (today.get(Calendar.YEAR) > dolmp.get(Calendar.YEAR)) {
                weeks = weeks + 52;
            }

            return weeks;
        }
    }
}

*/








/*        mDate.setOnClickListener(new.OnClickListener() {
          @Override
            public void onClick(View view) {
                c = Calendar.getInstance();
                int day = c.get(Calendar.DAY_OF_MONTH);
                int month = c.get(Calendar.MONTH);
                int year = c.get(Calendar.YEAR);

                /*dpd = new DatePickerDialog(Gestational_Period.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int mYear, int mMonth, int mDay) {
                        mLmp.setText(mDay + "/" + (mMonth+1) + "/" + mYear);
                    }
                }, day, month, year);*/
   /*             DatePickerDialog dateDialog = new DatePickerDialog(view.getContext(), datePickerListener, day, month, year);
                dateDialog.getDatePicker().setMaxDate(new Date().getTime());
                dateDialog.show();
                //dpd.show();

            }
        });
    }

    private DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year1, int month1, int day1) {
            Calendar today = Calendar.getInstance();
            today.set(Calendar.YEAR, year1);
            today.set(Calendar.MONTH, month1);
            today.set(Calendar.DAY_OF_MONTH, day1);
            String format = new SimpleDateFormat("DD MM YYYY").format(today.getTime());
            mLmp.setText(format);
            mGp.setText(Integer.toString(calculateGestationalPeriod(today.getTimeInMillis())) + "Weeks" );


        }
    };

    int calculateGestationalPeriod(long date){

        Calendar dolmp = Calendar.getInstance();
        dolmp.setTimeInMillis(date);
        Calendar today1 = Calendar.getInstance();
        today1.setTimeInMillis(date);
        int weeks;

        String currentDateString = today1.DateFormat.getDateTimeInstance().format(new Date());
        if ((today1.get(Calendar.YEAR))>(dolmp.get(Calendar.YEAR))) {

            weeks = today1.get(Calendar.WEEK_OF_YEAR) + (52 - dolmp.get(Calendar.WEEK_OF_YEAR));
        }

        else{

            weeks = today1.get(Calendar.WEEK_OF_YEAR) - dolmp.get(Calendar.WEEK_OF_YEAR);
        }
        return weeks;
    }

}

*/