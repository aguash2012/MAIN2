package com.example.preggahoop;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.CalendarView;

public class CalendarActivity extends AppCompatActivity {

    private static final String TAG = "CalendarActivity";

    private CalendarView mcv;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calendar_layout);

        mcv = (CalendarView)findViewById(R.id.calendarView);

        mcv.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@androidx.annotation.NonNull CalendarView view, int year, int month, int day) {
                String date = day + "/" + (month + 1)+ "/" + year;
                Log.d(TAG, "onSelectedDayChange: dd/mm/yyyy: " date);

                Intent intent = new Intent(CalendarActivity.this, Gestational_Period.class);
                intent.putExtra("date", date);
                startActivity(intent);


            }
        });
    }
}
